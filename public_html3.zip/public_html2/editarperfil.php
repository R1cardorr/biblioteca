<!doctype html>
<html lang="en">
  <head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Editar perfil</title>
  </head>
  <body>
    <h1>Editar perfil</h1>
  </body>
  
<form>
<div class="mb-3">
<label>Nome:</label>
<input type="text" name="nome" placeholder="Digite seu nome" class="form-control">
</div>
<p

<div class="mb-3">
<label>Telefone:</label>
<input type="number" name="text" placeholder="(+55)*****-****" class="form-control">
</div>
<p

<div class="mb-3">
<label>Turma:</label>
<input type="text" name="turma" placeholder="Digite sua turma" class="form-control">
</div>
<p

<div class="mb-3">
<button type="submit" class="btn btn-primary">Enviar</button>
</div>

 </form>
  
  
  
  
  </html>