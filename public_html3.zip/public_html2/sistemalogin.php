<?php

require_once('src/conn.php'); 
$dbc = mysqli_connect(DB_HOST, DB_USER, DB_PASSWORD, DB_NAME); 

$nome = $_POST['nome_login'];
$rm = $_POST['rm_login'];

$sql = ("SELECT rm FROM cadastro_us WHERE rm = '".$rm."' AND nome = '".$nome."';");
    
$result = mysqli_query($dbc, $sql);

if (mysqli_num_rows($result) > 0) {
    header("Location:home.php");
} 
else {
    header("Location:index.php");
}
 
?>