<?php
require_once __DIR__ . '../../src/constants.php';
?>
<p><h2onheça mais sobre a gente</h2/p>
<a href="<?= PATH_ABOUT ?>">Sobre a Biblioteca Escolar</a>
<br>
<a href="../index.php">Voltar</a>
</body>
</html>