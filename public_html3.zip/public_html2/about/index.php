<?php 
require_once __DIR__ . '../../inc/head.php';
?> 
<h1>Sobre</h1>
<p>Este projeto está sendo desenvolvido pelos alunos do 2º ano de Desenvolvimento de Sistemas, 
    com o objetivo de facilitar o acesso ao sistema de biblioteca da Etec José Sant'Ana de Castro
</p>
<?php 
require_once __DIR__ . '../../inc/footer.php';
?>

