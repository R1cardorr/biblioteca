<!doctype html>
<html lang="en">
  <head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Perfil</title>
  </head>
  <body>
    <h1>Perfil</h1>
  </body>



 <h1> <a href ="editarperfil.php">Editar perfil</a></h1>
  
  <h1> <a href ="excluirperfil.php">Excluir perfil</a></h1>


 
 
</html>
