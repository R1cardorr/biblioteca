<?php
define('PATH', 'https://sistema-bibliotecarioo.000webhostapp.com/about/index.php');
define('PATH_ABOUT', 'https://sistema-bibliotecarioo.000webhostapp.com/about/index.php');
define('PATH_CSS', 'http://localhost/project-bibliotec/css');