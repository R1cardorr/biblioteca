<?php
define('DB_HOST', 'localhost');
define('DB_USER', 'id19106227_aagrtvv');
define('DB_PASSWORD', '8)cwBE5|WG2F9w=#');
define('DB_NAME', 'id19106227_biblioteca_escolar');
?>