<?php



require_once('src/conn.php');

session_start();



$error_msg = "";



$dbc = mysqli_connect(DB_HOST, DB_USER, DB_PASSWORD, DB_NAME);



if (!$dbc) {
$_SESSION["errorConnect"] = mysqli_connect_error();
}



?>



<?php
require_once ('inc/head.php')
?>

<a href ="perfil.php">Perfil</a>

<h1>Livros</h1>
<?php 
$dbc = mysqli_connect(DB_HOST, DB_USER, DB_PASSWORD, DB_NAME);

      $query = "SELECT * FROM livros";

      $data = mysqli_query($dbc, $query);

      while ($row = mysqli_fetch_array($data)) {
        ?>
          <h3>id: <?php echo $row['id_livro']; ?> </h3>
          <hr>
          <h3>nome: <?php echo $row['nome']; ?> </h3>
          <hr>
          <h3>Gênero: <?php echo $row['genero']; ?> </h3>
          <hr>
          <h3>Autor: <?php echo $row['autor']; ?> </h3>
          <hr>
          <h3>Data de lançamento: <?php echo $row['data_lançamento']; ?> </h3>
          <hr>
          <h3>Disponibilidade: <?php echo $row['disponibilidade']; ?> </h3>
          <hr>
        </div>
      </div>
        <?php

      }
      ?>
<?php
require_once ('inc/footer.php');
?>
</html>
    