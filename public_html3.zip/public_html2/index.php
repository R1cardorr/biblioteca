<?php
require_once('src/conn.php');
require_once __DIR__ . '/inc/head.php';



$error_msg = "";

$dbc = mysqli_connect(DB_HOST, DB_USER, DB_PASSWORD, DB_NAME);

if (!$dbc) {
$_SESSION["errorConnect"] = mysqli_connect_error();
}

?>


<script src="https://code.jquery.com/jquery-3.3.1.slim.min.js" integrity="sha384-q8i/X+965DzO0rT7abK41JStQIAqVgRVzpbzo5smXKp4YfRvH+8abtTE1Pi6jizo" crossorigin="anonymous"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.14.3/umd/popper.min.js" integrity="sha384-ZMP7rVo3mIykV+2+9J3UJ46jBk0WLaUAdn689aCwoqbBJiSnjAK/l8WvCWPIPm49" crossorigin="anonymous"></script>
    <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.1.3/js/bootstrap.min.js" integrity="sha384-ChfqqxuZUCnJSK3+MXmPNIyE6ZbWh2IMqE241rYiqJxyMiZ6OW/JmZQ5stwEULTy" crossorigin="anonymous"></script>

    <!DOCTYPE html>
<head>
  <meta charset="UTF-8" />
  <title>Formulário de Login e Registro com HTML5 e CSS3</title>
  <meta name="viewport" content="width=device-width, initial-scale=1.0"> 
  <link rel="stylesheet" type="text/css" href="Css/style.css" />
</head>
<body>
  <div class="container" >
    <a class="links" id="paracadastro"></a>
    <a class="links" id="paralogin"></a>
    
    
    <div class="content">
      <!--FORMULÁRIO DE LOGIN-->
      <div id="login">
        <form method="post" action="sistemalogin.php"> 
          <h1>Login</h1> 
          <p> 
            <label for="nome_login">Nome</label>
            <input id="nome_login" name="nome_login" required="required" type="text" placeholder="Nome"/>
          </p>

          <p> 
            <label for="rm_login">RM</label>
            <input id="rm_login" name="rm_login" required="required" type="number" placeholder="12345" /> 
          </p>

          <p> 
            <input type="checkbox" name="manterlogado" id="manterlogado" value="" /> 
            <label for="manterlogado">Manter-me logado</label>
          </p>

         <p>
            
          <input type="submit" value="Logar" />
           
          </p>
          <p class="link">
            Ainda não possui uma conta?
            <a href="cadastro.php"> Cadastre-se </a>
          </p>
        </form>
      </div>
  
      <meta name="viewport" content="width=device-width, initial-scale=1">

         
     


