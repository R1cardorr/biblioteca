<?php

require_once('src/conn.php'); 
$dbc = mysqli_connect(DB_HOST, DB_USER, DB_PASSWORD, DB_NAME); 

$nome = $_POST['nomeS_cad']; 
$rm = $_POST['rm_cad']; 
$telefone = $_POST['telefone_cad']; 
$turma = $_POST['turma_cad']; 

$sql = ("SELECT rm FROM cadastro_us WHERE rm = '".$rm."';");
    
$result = mysqli_query($dbc, $sql);

if (mysqli_num_rows($result) > 0) {
    echo "Este usuário já está cadastrado no sistema.";
} 
else {
    $query = mysqli_query($dbc, "INSERT INTO cadastro_us(nome, rm, telefone, turma)
    VALUES ('$nome', '$rm', '$telefone', '$turma')");
    header("Location:index.php");
}
 
?>