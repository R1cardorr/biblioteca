-- MySQL dump 10.13  Distrib 8.0.27, for Win64 (x86_64)
--
-- Host: localhost    Database: id19106227_biblioteca_escolar
-- ------------------------------------------------------
-- Server version	8.0.26

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `biblioteca`
--

DROP TABLE IF EXISTS `biblioteca`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `biblioteca` (
  `id_biblioteca` int NOT NULL,
  `nome_da_biblioteca` varchar(45) NOT NULL,
  `telefone` varchar(20) NOT NULL,
  `escola_pertencente` varchar(45) NOT NULL,
  PRIMARY KEY (`id_biblioteca`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `biblioteca`
--

LOCK TABLES `biblioteca` WRITE;
/*!40000 ALTER TABLE `biblioteca` DISABLE KEYS */;
INSERT INTO `biblioteca` VALUES (77,'CruzeTEC','31441207','Prof. José Sant’Ana de Castro');
/*!40000 ALTER TABLE `biblioteca` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `bibliotecario`
--

DROP TABLE IF EXISTS `bibliotecario`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `bibliotecario` (
  `id_bibliotecario` int NOT NULL AUTO_INCREMENT,
  `nome` varchar(45) NOT NULL,
  `email` varchar(45) NOT NULL,
  `biblioteca_id_biblioteca` int DEFAULT NULL,
  PRIMARY KEY (`id_bibliotecario`),
  KEY `fk_bibliotecario_biblioteca1` (`biblioteca_id_biblioteca`),
  CONSTRAINT `fk_bibliotecario_biblioteca1` FOREIGN KEY (`biblioteca_id_biblioteca`) REFERENCES `biblioteca` (`id_biblioteca`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `bibliotecario`
--

LOCK TABLES `bibliotecario` WRITE;
/*!40000 ALTER TABLE `bibliotecario` DISABLE KEYS */;
INSERT INTO `bibliotecario` VALUES (1,'Jorge da Silva','jorgesilva@gmail.com',77),(2,'Maria Madalena','madaleninha53@gmail.com',77);
/*!40000 ALTER TABLE `bibliotecario` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `cadastro_us`
--

DROP TABLE IF EXISTS `cadastro_us`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `cadastro_us` (
  `id_cadadstro` int NOT NULL AUTO_INCREMENT,
  `nome` varchar(45) NOT NULL,
  `rm` varchar(5) NOT NULL,
  `telefone` varchar(20) NOT NULL,
  `turma` varchar(45) NOT NULL,
  `biblioteca_id_biblioteca` int DEFAULT NULL,
  PRIMARY KEY (`id_cadadstro`),
  KEY `fk_cadastro_us_biblioteca1` (`biblioteca_id_biblioteca`),
  CONSTRAINT `fk_cadastro_us_biblioteca1` FOREIGN KEY (`biblioteca_id_biblioteca`) REFERENCES `biblioteca` (`id_biblioteca`)
) ENGINE=InnoDB AUTO_INCREMENT=31 DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `cadastro_us`
--

LOCK TABLES `cadastro_us` WRITE;
/*!40000 ALTER TABLE `cadastro_us` DISABLE KEYS */;
INSERT INTO `cadastro_us` VALUES (1,'Juliane Bonde','20896','12998563321','2 Desenvolvimento De Sistemas',77),(2,'Daniel Augusto','20765','12998564121','1 Edificações',77),(3,'Breno Londres','20654','12988265487','3 Mecânica',77),(4,'Jussara Silva','20548','12997569923','1 Desenvolvimento de Sistemas',77),(5,'Maria de Lurdes','20237','12998654778','2 Logística',77),(6,'Gabriela Guedez','20021','12998256697','3 Desenvolvimento De Sistemas',77),(7,'Bianca Ribeiro','20864','12998265541','2 Nutrição',77),(8,'Giovana SantAnna','20887','12998322107','1 Desenvolvimento De Sistemas',77),(9,'Lucas Felipe','20899','12998002156','2 Mecânica',77),(10,'Maycon Douglas','20654','12998788521','1 Edificações',77),(11,'Ricardo Santos','20841','12998568974','2 Marketing',77),(12,'João Victor','20899','12998890026','1 Desenvolvimento De Sistemas',77),(13,'Arthur Henrique','20852','12998778109','2 Logística',77),(14,'Guilherme Marques','20883','12998552169','3 Mecânica',77),(15,'Sofia Inácio','20875','12998566804','3 Desenvolvimento De Sistemas',77),(16,'Mariana Morais','20999','12937278653','1 Logística',77),(17,'Igor Gabriel','20335','12997401285','3 Desenvolvimento De Sistemas',77),(18,'Felipe Vieira','21564','12992146058','2 Marketing',77),(19,'Kauany Mendes','20760','12993703384','1 Edificações',77),(20,'Bianca Guedes','25632','12997536115','2 Desenvolvimento De Sistemas',77),(21,'Joyce rodrigues','20681','12994083521','1 Nutrição',77),(22,'Henrique Videira','20539','129811102554','2 Ciências Biológicas Agrárias',77),(23,'Julia Batista','20898','12981620104','2 Ciências Biológicas Agrárias',77),(24,'Miguel Sollano','20496','12966307345','3 Logística',77),(25,'Jeremias Correia','20845','12998563326','3 Desenvolvimento De Sistemas',77),(26,'Eduardo Nogueira','21846','12998563923','1 Desenvolvimento De Sistemas',77),(27,'Erick Cabral','20456','12995553321','2 Mecânica',77),(28,'Kaio Vitor','20336','12992586541','2 Desenvolvimento De Sistemas',77),(29,'Mário Flores','20886','12998569521','1 Edificações',77),(30,'João Vitor','20496','12982563321','1 Nutrição',77);
/*!40000 ALTER TABLE `cadastro_us` ENABLE KEYS */;
UNLOCK TABLES;


--
-- Table structure for table `livros`
--

DROP TABLE IF EXISTS `livros`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `livros` (
  `id_livro` int NOT NULL AUTO_INCREMENT,
  `nome` varchar(45) NOT NULL,
  `genero` varchar(175) NOT NULL,
  `autor` varchar(45) NOT NULL,
  `data_lançamento` varchar(45) NOT NULL,
  `disponibilidade` varchar(15) NOT NULL,
  `biblioteca_id_biblioteca` int DEFAULT NULL,
  PRIMARY KEY (`id_livro`),
  KEY `fk_livros_biblioteca1` (`biblioteca_id_biblioteca`),
  CONSTRAINT `fk_livros_biblioteca1` FOREIGN KEY (`biblioteca_id_biblioteca`) REFERENCES `biblioteca` (`id_biblioteca`)
) ENGINE=InnoDB AUTO_INCREMENT=31 DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `livros`
--

LOCK TABLES `livros` WRITE;
/*!40000 ALTER TABLE `livros` DISABLE KEYS */;
INSERT INTO `livros` VALUES (1,'É assim que acaba','Romance de amor, Ficção, Romance contemporâneo','Colleen Hoover','08/02/2016','alugado',77),(2,'O pequeno princípe','Literatura infantil, Fábula, Novela, Ficção especulativa','Antoine de Saint-Exupéry','04/06/1943','alugado',77),(3,'A seleção',' Romance, Ficção juvenil, Literatura fantástica, Ficção distópica','Kiera Cass','04/14/2012','alugado',77),(4,'A elite','Romance, Ficção juvenil, Literatura fantástica','Kiera Cass','04/23/2013','disponível',77),(5,'A escolha','Ficção','Kiera Cass','05/06/2014','alugado',77),(6,'A herdeira','Romance, Literatura fantástica, Ficção distópica','Kiera Cass','05/05/2015','alugado',77),(7,'A coroa','Ficção','Kiera Cass','04/26/2016','disponível',77),(8,'Como sobreviver à realeza','Ficção','Rachel Hawkins','05/01/2018','disponível',77),(9,'Sua alteza real','Romance, Romance de amor, Ficção','Rachel Hawkins','10/19/2020','disponível',77),(10,'Mil beijos de garoto','Romance de amor, Ficção','Tillie Colie','03/15/2016','disponível',77),(11,'As mil partes de meu coração','Romance contemporâneo, Romance psicológico, Ficção Doméstica','Colleen Hoover','10/03/2017','disponível',77),(12,'Os Sete Maridos de Evelyn Hugo','Romance, Romance de amor, Ficção histórica, Romance psicológico','Taylor Jenkins Reid','06/13/2017','alugado',77),(13,'Todas as suas (im)perfeições',' Romance de amor, Romance contemporâneo, Romance psicológico, Ficção Doméstica','Colleen Hoover','07/17/2018','disponível',77),(14,'O lado feio do amor','Ficção, Romance de amor','Colleen Hoover','08/14/2015','alugado',77),(15,'Em busca de Cinderela e em busca da perfeição','Ficção de novo adulto','Colleen Hoover','04/04/2022','disponível',77),(16,'Suzy e as águas -vivas','Ficção e Romance ','Ali Benjamin','09/22/2015','alugado',77),(17,'A princesa salva a si mesma neste livro','Poesia','Amanda Lovelace','04/23/2016','disponível',77),(18,'De volta aos quinze','Drama adolescente','Bruna Vieira','08/23/2013','alugado',77),(19,'A menina que colecionava borboletas','Crônica','Bruna Vieira','01/24/2014','disponível',77),(20,'Garota em pedaços','Ficção e Romance','Kathleen Glasgow','08/22/2016','alugado',77),(21,'Coisas que guardei pra mim','Poesia','Samara A. Buchweitz','05/11/2021','disponível',77),(22,'Moletom',' Ficção juvenilr','Julio Azevedo','12/20/2017','alugado',77),(23,'A Rainha Vermelha','Romance, Ficção juvenil, Literatura fantástica, Alta fantasia','Victoria Aveyard','06/9/2015','disponível',77),(24,'Um de Nós Mente','Ficção e Suspense','Karen M. McManus','02/12/2018','alugado',77),(25,'A Menina que Roubava Livros','Romance, Ficção juvenil, Ficção histórica','Markus Zusak','02/15/2007','disponível',77),(26,'Deixei meu coração em modo avião','Crônicas, Não-ficção, Romance','Fabíola Simõesr','07/06/2020','alugado',77),(27,'A cinco passos de você','Ficção e Romance de amor','Mikki Daughtry e Tobias Iaconis','11/20/2018','disponível',77),(28,'A vida não é uma linha reta','Crônicas/ Não-ficção','Fabi Santina','11/30/2021','alugado',77),(29,'Em Algum Lugar nas Estrelas','Literatura infantil e Ficção de aventura','Clare Vanderpool','01/08/2013','disponível',77),(30,'Um lugar só nosso','Romance para jovens e adolescentes','Maurene Goo','03/03/2020','alugado',77);
/*!40000 ALTER TABLE `livros` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `usuario`
--

DROP TABLE IF EXISTS `usuario`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `usuario` (
  `id_usuario` int NOT NULL AUTO_INCREMENT,
  `nome` varchar(45) NOT NULL,
  `rm` varchar(5) NOT NULL,
  `cadastro_us_id_cadadstro` int DEFAULT NULL,
  `biblioteca_id_biblioteca` int DEFAULT NULL,
  PRIMARY KEY (`id_usuario`),
  KEY `fk_usuario_cadastro_us` (`cadastro_us_id_cadadstro`),
  KEY `fk_usuario_biblioteca1` (`biblioteca_id_biblioteca`),
  CONSTRAINT `fk_usuario_biblioteca1` FOREIGN KEY (`biblioteca_id_biblioteca`) REFERENCES `biblioteca` (`id_biblioteca`),
  CONSTRAINT `fk_usuario_cadastro_us` FOREIGN KEY (`cadastro_us_id_cadadstro`) REFERENCES `cadastro_us` (`id_cadadstro`)
) ENGINE=InnoDB AUTO_INCREMENT=31 DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `usuario`
--

LOCK TABLES `usuario` WRITE;
/*!40000 ALTER TABLE `usuario` DISABLE KEYS */;
INSERT INTO `usuario` VALUES (1,'Juliane Bonde','20896',NULL,NULL),(2,'Daniel Augusto','20765',NULL,NULL),(3,'Breno Londres','20654',NULL,NULL),(4,'Jussara Silva','20548',NULL,NULL),(5,'Maria de Lurdes','20237',NULL,NULL),(6,'Gabriela Guedez','20021',NULL,NULL),(7,'Bianca Ribeiro','20864',NULL,NULL),(8,'Giovana SantAnna','20887',NULL,NULL),(9,'Lucas Felipe','20899',NULL,NULL),(10,'Maycon Douglas','20654',NULL,NULL),(11,'Ricardo Santos','20841',NULL,NULL),(12,'João Victor','20899',NULL,NULL),(13,'Arthur Henrique','20852',NULL,NULL),(14,'Guilherme Marques','20883',NULL,NULL),(15,'Sofia Inácio','20875',NULL,NULL),(16,'Mariana Morais','20999',NULL,NULL),(17,'Igor Gabriel','20335',NULL,NULL),(18,'Felipe Vieira','21564',NULL,NULL),(19,'Kauany Mendes','20760',NULL,NULL),(20,'Bianca Guedes','25632',NULL,NULL),(21,'Joyce rodrigues','20681',NULL,NULL),(22,'Henrique Videira','20539',NULL,NULL),(23,'Julia Batista','20898',NULL,NULL),(24,'Miguel Sollano','20496',NULL,NULL),(25,'Jeremias Correia','20845',NULL,NULL),(26,'Eduardo Nogueira','21846',NULL,NULL),(27,'Erick Cabral','20456',NULL,NULL),(28,'Kaio Vitor','20336',NULL,NULL),(29,'Mário Flores','20886',NULL,NULL),(30,'João Vitor','20496',NULL,NULL);
/*!40000 ALTER TABLE `usuario` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2022-06-15 14:55:05
