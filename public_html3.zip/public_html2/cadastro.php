<?php
require_once ('inc/head.php');
?>

<body>  
<head>
<meta charset="UTF-8" />
  <title>Formulário de Login e Registro com HTML5 e CSS3</title>
  <meta name="viewport" content="width=device-width, initial-scale=1.0"> 
</head>

<body>  

<script src="https://code.jquery.com/jquery-3.3.1.slim.min.js" integrity="sha384-q8i/X+965DzO0rT7abK41JStQIAqVgRVzpbzo5smXKp4YfRvH+8abtTE1Pi6jizo" crossorigin="anonymous"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.14.3/umd/popper.min.js" integrity="sha384-ZMP7rVo3mIykV+2+9J3UJ46jBk0WLaUAdn689aCwoqbBJiSnjAK/l8WvCWPIPm49" crossorigin="anonymous"></script>
    <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.1.3/js/bootstrap.min.js" integrity="sha384-ChfqqxuZUCnJSK3+MXmPNIyE6ZbWh2IMqE241rYiqJxyMiZ6OW/JmZQ5stwEULTy" crossorigin="anonymous"></script>
    <link rel="stylesheet" type="text/css" href="Css/style.css" />

    <div class="container" >
    <a class="links" id="paracadastro"></a>
    <a class="links" id="paralogin"></a>

    <div class="content">
<!--FORMULÁRIO DE CADASTRO-->
      <div id="cadastro">
         <form action="sistemacadastro.php" method="POST">
         
         <h1>Cadastro</h1> 

          <p> 
            <label for="nome_cad">Nome</label>
            <input id="nome_cad" name="nomeS_cad" required="required" type="text" placeholder="Nome" />
          </p>

          <p> 
            <label for="rm_cad">RM</label>
            <input id="rm_cad" name="rm_cad" required="required" type="number" placeholder="12345"/> 
          </p>

          <p> 
            <label for="telefone_cad">Telefone</label>
            <input id="telefone_cad" name="telefone_cad" required="required" type="text" placeholder="()****-****"/>
          </p>
          
           <p> 
            <label for="turma_cad">Turma</label>
            <input id="turma_cad" name="turma_cad" required="required" type="text" placeholder="2 DS"/>
          </p>

          <p> 
            <input type="submit" name="submit_cad" value="Cadastrar" />
          </p>

          <p class="link">
            Já tem conta?
            <a href="index.php"> Ir para Login </a>
          </p>
        </form>
      </div>
    </div>
  </div>


</body> 




  

</body> 
<?php
require_once ('inc/footer.php');
?>

</html> 